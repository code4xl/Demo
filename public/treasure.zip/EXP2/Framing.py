def character_count():

    frame=int(input("Enter no. of frames:"))
    final=''
    for i in range(0,frame):
        data=input(f"Enter string {i+1}:")
        char_count=str(len(data)+1)+data
        final+=char_count

    return final


def byte_stuffing():
    
    message=input("Enter the message:")

    start=input("Enter start flag:")
    end=input("Enter end flag:")

    escape=input("Enter the escape character:")
    final=""

    for i in range(0,len(message)):
        if(message[i]==start or message[i]==end):
            final+=escape+message[i]
        else:
            final+=message[i]

    return start+final+end



def bit_stuffing():
    msg=input("Enter data to be sent")
    c=0
    final=''
    for i in msg:
        if(i=='1'):
            c+=1
        else:
            c=0
        final+=i
        if(c==5):
            final+='0'
            c=0
    print(final)                    



print("character c:")
transmitted_message_character_count=character_count()
print("transmitted message character c:"+transmitted_message_character_count)


print("byte stuffing:")
transmitted_message_byte_stuffing=byte_stuffing()
print("transmitted message byte stuffing:"+transmitted_message_byte_stuffing)


print("bit stuffing:")
transmitted_message_bit_stuffing=bit_stuffing()
print("transmitted message bit stuffing:"+transmitted_message_bit_stuffing)






# def byte_stuffing(data, flag='11111111', escape='11111110'):

#     # Split the input data into 8-bit chunks
#     bytes_list = [data[i:i+8] for i in range(0, len(data), 8)]
#     stuffed_data = []

#     for byte in bytes_list:
#         # If the byte matches the flag or escape byte, add the escape byte first
#         if byte == flag or byte == escape:
#             stuffed_data.append(escape)
#         stuffed_data.append(byte)
    
#     # Join the stuffed data list back into a single binary string
#     return ''.join(stuffed_data)

# def byte_unstuffing(stuffed_data, flag='11111111', escape='11111110'):

#     # Split the stuffed data into 8-bit chunks
#     bytes_list = [stuffed_data[i:i+8] for i in range(0, len(stuffed_data), 8)]
#     unstuffed_data = []
#     escape_next = False

#     for byte in bytes_list:
#         if escape_next:
#             # Directly add the byte after an escape byte
#             unstuffed_data.append(byte)
#             escape_next = False
#         elif byte == escape:
#             # Set flag to escape the next byte
#             escape_next = True
#         else:
#             # Otherwise, add the byte to unstuffed data
#             unstuffed_data.append(byte)
    
#     # Join the unstuffed data list back into a single binary string
#     return ''.join(unstuffed_data)

# # Example usage
# data = "010010000110010101101100011011000110111111111111010101110110111101110010111111100110110001100100"
# print("Original Data:", data)

# stuffed = byte_stuffing(data)
# print("Stuffed Data:", stuffed)

# unstuffed = byte_unstuffing(stuffed)
# print("Unstuffed Data:", unstuffed)
