def crc(data, divisor):
    n = len(divisor)
    temp = data + '0' * (n - 1)  # Append zeros 
    temp = list(temp)
    divisor = list(divisor)
    for i in range(len(data)):
        if temp[i] == '1':
            for j in range(n):
                temp[i + j] = str(int(temp[i + j]) ^ int(divisor[j]))
    
    remainder = ''.join(temp[-(n - 1):]) 
    return remainder

def crc2(received_data, divisor):
    n = len(divisor)
    temp = list(received_data)  # Dont append zeros
    divisor = list(divisor)
    for i in range(len(received_data) - n + 1):
        if temp[i] == '1':
            for j in range(n):
                temp[i + j] = str(int(temp[i + j]) ^ int(divisor[j]))
    
    remainder = ''.join(temp[-(n - 1):]) 
    return remainder
#both are same functions except for appending zeros part

#Sender Side
data = input("Enter data to be sent: ")
key = input("Enter key: ")

checksum = crc(data, key)
sent_data = data + checksum
print(f"Sent data: {sent_data}")

#Receiver side
received_data = input("Enter received data: ")
remainder = crc2(received_data, key)

if int(remainder) == 0:
    print("Data received without errors.")
else:
    print(f"Error detected in received data. Remainder: {remainder}")




#CRC..
# def bin_div(dividend,divisor):
       
#     remainder = []
    
#     lst = dividend[0:len(divisor)]
    
#     for i in range(len(dividend)-len(divisor)+1):
#         if lst[0] == 0:
#             comp = [0] * len (divisor)
#         else:
#             comp = divisor
    
#         remainder = [(lst[c] ^ comp[c] )for c in range(len(divisor))]
        
#         lst = remainder[1:]
        
#         if i!= (len(dividend)-len(divisor)):
#             lst.append(dividend[i+ len(divisor)]) 
    
#     return lst , dividend


# dividend = list(int(ch) for ch in list(input("enter the dividend: ")))
# divisor = list(int(ch) for ch in list(input("enter the key: ")))

# for i in range(len(divisor)-1):
#     dividend.append(0)

# l,d = bin_div(dividend,divisor)

# enc_data = dividend[:len(dividend)-len(l)] + l

# rem, div = bin_div(enc_data,divisor)

# rem = "".join(map(str,rem))
# print(rem)


# if int(rem) != 0 :
#     print("error")
# else : 
#     print("no error")