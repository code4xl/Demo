#5 bit data aaya toh 4 parity le lena baaki same karo aage
array = [None] * 7
data = input("Enter 4-bit data to send: ")

if len(data) != 4:
    print("Error")
else:
    array[0] = int(data[0])#position D7
    array[1] = int(data[1])#position D6  
    array[2] = int(data[2])#position D5
    array[4] = int(data[3])#position D3

    def iseven(sum):
        if sum % 2 == 0:
            return 0
        else:
            return 1

    sum1 = array[0] + array[2] + array[4]
    sum2 = array[1] + array[2] + array[4]
    sum3 = array[0] + array[1] + array[2]

    p1 = iseven(sum1)
    p2 = iseven(sum2)
    p3 = iseven(sum3)

    array[6] = p1
    array[5] = p2
    array[3] = p3

    result = ''.join(map(str, array))
    print(result)



#########Hamming...
# choice=int(input("Enter \n1:Code Gen\n2:Error Detection"))

# if choice==1:
#     data=list(map(int,input("Enter 5 digit data:")))

#     if len(data)!=5:
#         print("Error!")
#     else:
#         code_array=[0,0,data[0],0,data[1],data[2],data[3],0,data[4]]

#         code_array[0]=(code_array[2]+code_array[4]+code_array[6]+code_array[8])%2
#         code_array[1]=(code_array[2]+code_array[5+code_array[6]])%2
#         code_array[3]=(code_array[4]+code_array[5]+code_array[6])%2
#         code_array[7]=(code_array[8])%2

#         code=''.join(str(i) for i in code_array)
#         print(f'Hamming code :{code}')

# elif choice==2:
#     code_array=list(map(int,input("Enter 9 digit data:")))
#     if len(code_array)!=9:
#         print("Error!")
#     else:

#         p1=(code_array[0]+code_array[2]+code_array[4]+code_array[6]+code_array[8])%2
#         p2=(code_array[1]+code_array[2]+code_array[5+code_array[6]])%2
#         p4=(code_array[3]+code_array[4]+code_array[5]+code_array[6])%2
#         p8=(code_array[7]+code_array[8])%2

#         error=p8*8+p4*4+p2*2+p1

#         if error==0:
#             print("No error")
#         else:
#             print("Error detected at position",error)
#             code_array[error-1]=(code_array[error-1]+1)%2
#             corrected_code=''.join(str(i) for i in code_array)
#             print("Corrected code:",corrected_code)
# else:
#     print("Invalid choice!")