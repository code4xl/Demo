#######SR1......

import time
import random

window_size = 4
total_frames = 10

sent_frames = [False] * total_frames
ack_received = [False] * total_frames

window_start = 0

while not all(ack_received):
    for i in range(window_start, min(window_start + window_size, total_frames)):
        if not sent_frames[i]:
            print(f"Sending frame {i}")
            sent_frames[i] = True
            time.sleep(1)

    for i in range(window_start, min(window_start + window_size, total_frames)):
        if not ack_received[i]:
            ack = random.random() < 0.7
            if ack:
                print(f"Received ACK for frame {i}")
                ack_received[i] = True
                time.sleep(1)
            else:
                print(f"Frame {i} lost. Will retransmit later.")
                sent_frames[i] = False
                time.sleep(1)

    while window_start < total_frames and ack_received[window_start]:
        window_start += 1

print(f"All {total_frames} frames sent and acknowledged.")


#######SR2......

# import time
# import random

# window_size = 4
# total_frames = 10
# sent_frames = 0
# ack_received = [False] * total_frames  # Track which frames have been acknowledged
# waiting_for_ack = []  # List to track the frames that have been sent but not acknowledged

# while any(not ack for ack in ack_received):  # Continue until all frames are acknowledged
#     # Send new frames up to window size
#     while sent_frames < total_frames and len(waiting_for_ack) < window_size:
#         print(f"Sending frame {sent_frames}")
#         waiting_for_ack.append(sent_frames)  # Add frame to the list of sent frames waiting for ACK
#         sent_frames += 1
#         time.sleep(1)

#     # Process ACKs (or simulate loss)
#     for frame in waiting_for_ack[:]:  # Iterate over frames that were sent but not acknowledged
#         ack = random.choice([True, False])  # Simulate whether the ACK is received for the frame
#         if ack:
#             print(f"ACK received for frame {frame}")
#             ack_received[frame] = True
#             waiting_for_ack.remove(frame)  # Remove frame from the waiting list
#         else:
#             print(f"ACK lost for frame {frame}, resending it")
#             # Frame is lost, re-add to the waiting list for retransmission
#             time.sleep(1)  # Simulate some delay before retransmitting the lost frame


#######SR3......
# import time
# import random

# window_size = 4
# total_frames = 10
# sent_frames = 0
# ack_received = [False] * total_frames 
# waiting_for_ack = []  

# while False in ack_received:
#     while sent_frames < total_frames and len(waiting_for_ack) < window_size:
#         print(f"Sending frame {sent_frames}")
#         waiting_for_ack.append(sent_frames) 
#         sent_frames += 1
#         time.sleep(1)

#     for i in waiting_for_ack: 
#         ack = random.choice([True, False]) 
#         if ack:
#             print(f"ACK received for frame {i}")
#             ack_received[i] = True
#             waiting_for_ack.remove(i)  
#         else:
#             print(f"ACK lost for frame {i}, resending it")
#             time.sleep(1) 


#######SR4......

# import time
# import random

# class SelectiveRepeat:
#     def _init_(self, window_size, total_frames):
#         self.window_size = window_size
#         self.total_frames = total_frames
#         self.sent_frames = [None] * total_frames  # None indicates frame has not been sent yet
#         self.ack_received = [False] * total_frames  # False means ACK not received yet
#         self.current_frame = 0  # Keeps track of the frame currently being processed

#     def send_frame(self, frame_num):
#         if self.sent_frames[frame_num] is None:  # If frame hasn't been sent yet
#             print(f"Sending frame {frame_num}")
#             self.sent_frames[frame_num] = True
#             time.sleep(1)  # Simulate time for sending

#     def receive_ack(self, frame_num):
#         ack = random.choice([True, False])  # Simulate random ACK/NACK
#         if ack:
#             print(f"ACK received for frame {frame_num}")
#             self.ack_received[frame_num] = True
#         else:
#             print(f"NACK for frame {frame_num}")

#     def send_frames(self):
#         while not all(self.ack_received):  # Keep sending until all ACKs are received
#             # Send all frames in the window that have not been acknowledged
#             for i in range(self.window_size):
#                 frame_num = (self.current_frame + i) % self.total_frames
#                 if not self.ack_received[frame_num]:
#                     self.send_frame(frame_num)
            
#             # Simulate receiving ACKs for sent frames
#             for i in range(self.window_size):
#                 frame_num = (self.current_frame + i) % self.total_frames
#                 if not self.ack_received[frame_num]:
#                     self.receive_ack(frame_num)

#             # Move window forward by one frame
#             self.current_frame = (self.current_frame + 1) % self.total_frames

# if _name_ == "_main_":
#     sr = SelectiveRepeat(window_size=4, total_frames=10)
#     sr.send_frames()