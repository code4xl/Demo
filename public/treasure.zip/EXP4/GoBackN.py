import time
import random

window_size = 4

total_frames = 10
sent_frames = 0

ack_received = 0

while ack_received < total_frames:
    for i in range(window_size):
        if sent_frames < total_frames:
            print(f"Sending frame {sent_frames}")
            sent_frames += 1
            time.sleep(1)

    for i in range(window_size):
        if ack_received < total_frames:
            ack = random.choice([True, False]) 
            if ack:
                print(f"ACK received for frame {ack_received}")
                ack_received += 1
            else:
                print(f"Frame {ack_received} lost, resending from this frame")
                sent_frames = ack_received
                break




#########GBN......
# import time
# import random

# class GoBackN:
#     def _init_(self, window_size, total_frames):
#         self.window_size = window_size
#         self.total_frames = total_frames
#         self.sent_frames = 0
#         self.ack_received = 0

#     def send_frames(self):
#         while self.ack_received < self.total_frames:
#             # Sending frames within the window
#             for i in range(self.window_size):
#                 if self.sent_frames < self.total_frames:
#                     print(f"Sending frame {self.sent_frames}")
#                     self.sent_frames += 1
#                 else:
#                     break
#                 time.sleep(0.5)  # Simulate time delay for sending

#             # Simulate receiving ACKs for sent frames
#             for i in range(self.window_size):
#                 if self.ack_received < self.sent_frames:
#                     ack = random.choice([True, False])  # Simulate ACK or loss
#                     if ack:
#                         print(f"ACK received for frame {self.ack_received}")
#                         self.ack_received += 1
#                     else:
#                         print(f"Frame {self.ack_received} lost. Resending from this frame...")
#                         self.sent_frames = self.ack_received
#                         break  # Go back to the unacknowledged frame
#                 else:
#                     break

# if _name_ == "_main_":
#     gbn = GoBackN(window_size=4, total_frames=10)
#     gbn.send_frames()